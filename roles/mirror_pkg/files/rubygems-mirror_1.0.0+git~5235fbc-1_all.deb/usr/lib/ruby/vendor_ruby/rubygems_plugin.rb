require 'rubygems/command_manager'
require 'rubygems/mirror/command'

Gem::CommandManager.instance.register_command :mirror
